import SwiftUI
import PlaygroundSupport
import UIKit
import AVFoundation

let downAnimation = Animation.linear.repeatForever(autoreverses: false)

struct ContentView: View {
    @State private var baloon_opacity = 0.0
    @State private var end_opacity = 0.0
    @State var s1hOffset = 100.0
    @State var s2hOffset = 100.0
    @State var d1hOffset = -100.0
    @State var d2hOffset = -100.0
    @State var ymoney1 = -250.00
    @State var ymoney2 = -240.00
    @State var ymoney3 = -230.00
    @State var ymoney4 = -220.00
    @State var curtain = -500.00
    
    
    var body: some View {
        ZStack{
        Image(uiImage: UIImage(named: "7.1.png")!)
                .resizable()
                .frame(width: 600, height: 400)
                .padding()
            HStack{
                ZStack{
        Image(uiImage: UIImage(named: "sx2.png")!)
                    .resizable()
                    .frame(width: 600, height: 400)
                    .padding()
                    .offset(x:s2hOffset)
                    .onAppear(perform: {
                        withAnimation(Animation.linear.speed(0.1)){
                             s2hOffset = -200
                             
                         }})
        Image(uiImage: UIImage(named: "sx.png")!)
                    .resizable()
                    .frame(width: 600, height: 400)
                    .padding()
                    .offset(x:s1hOffset)
                    .onAppear(perform: {
                        withAnimation(Animation.linear.speed(0.15)){
                             s1hOffset = -200
                        }})
                }
                ZStack{
        Image(uiImage: UIImage(named: "dx2.png")!)
                    .resizable()
                    .frame(width: 600, height: 400)
                    .padding()
                    .offset(x:d2hOffset)
                    .onAppear(perform: {
                        withAnimation(Animation.linear.speed(0.1)){
                             d2hOffset = 200
                        }})
        Image(uiImage: UIImage(named: "dx.png")!)
                    .resizable()
                    .frame(width: 600, height: 400)
                    .padding()
                    .offset(x:d1hOffset)
                    .onAppear(perform: {
                        withAnimation(Animation.linear.speed(0.15)){
                             d1hOffset = 200
                        }})
                }
                
            }
            
            HStack{
                Image(uiImage: UIImage(named: "money1.png")!)
                            .resizable()
                            .frame(width: 50, height: 50)
                            .padding()
                            .offset(y:ymoney1)
                            .onAppear(perform: {
                                withAnimation(downAnimation.delay(0.5).speed(0.4)){
                                    ymoney1 = 250
                                }})
                Image(uiImage: UIImage(named: "money2.png")!)
                            .resizable()
                            .frame(width: 50, height: 50)
                            .padding()
                            .offset(y:ymoney2)
                            .onAppear(perform: {
                                withAnimation(downAnimation.delay(0.5).speed(0.3)){
                                    ymoney2 = 250
                                }})
                Image(uiImage: UIImage(named: "money3.png")!)
                            .resizable()
                            .frame(width: 50, height: 50)
                            .padding()
                            .offset(y:ymoney3)
                            .onAppear(perform: {
                                withAnimation(downAnimation.delay(0.5).speed(0.2)){
                                    ymoney3 = 250
                                }})
                Image(uiImage: UIImage(named: "money4.png")!)
                            .resizable()
                            .frame(width: 50, height: 50)
                            .padding()
                            .offset(y:ymoney4)
                            .onAppear(perform: {
                                withAnimation(downAnimation.delay(0.5).speed(0.1)){
                                    ymoney4 = 250
                                }})
            
                Image(uiImage: UIImage(named: "money1.png")!)
                            .resizable()
                            .frame(width: 50, height: 50)
                            .padding()
                            .offset(y:ymoney1)
                            .onAppear(perform: {
                                withAnimation(downAnimation.delay(0.5).speed(0.4)){
                                    ymoney1 = 250
                                }})
                Image(uiImage: UIImage(named: "money2.png")!)
                            .resizable()
                            .frame(width: 50, height: 50)
                            .padding()
                            .offset(y:ymoney2)
                            .onAppear(perform: {
                                withAnimation(downAnimation.delay(0.5).speed(0.3)){
                                    ymoney2 = 250
                                }})
                Image(uiImage: UIImage(named: "money3.png")!)
                            .resizable()
                            .frame(width: 50, height: 50)
                            .padding()
                            .offset(y:ymoney3)
                            .onAppear(perform: {
                                withAnimation(downAnimation.delay(0.5).speed(0.2)){
                                    ymoney3 = 250
                                }})
                Image(uiImage: UIImage(named: "money4.png")!)
                            .resizable()
                            .frame(width: 50, height: 50)
                            .padding()
                            .offset(y:ymoney4)
                            .onAppear(perform: {
                                withAnimation(downAnimation.delay(0.5).speed(0.1)){
                                    ymoney4 = 250
                                }})
                
            }
            
            
            Image(uiImage: UIImage(named: "box_testo.png")!)
            .resizable()
            .frame(width: 600, height: 190)
            .offset(y:150)
            .padding(20)
            .opacity(baloon_opacity)
            .onAppear(perform: {withAnimation(Animation.easeIn)
                {
                    baloon_opacity = 1

                }})
            

                Text("...and finally she began to follow her dream!")
                    .foregroundColor(Color(red:255,green:0,blue:255))
                    .bold()
                    .frame(width: 570, height: 100)
                    .offset(y:170)
                    .padding(20)
                    .opacity(baloon_opacity)
                    .animation(Animation.easeIn.delay(2))
            
            Image(uiImage: UIImage(named: "curtain.png")!)
            .resizable()
            .frame(width: 600, height: 800)
            .offset(y:curtain)
            .onAppear(perform: {
                withAnimation(Animation.linear.delay(1).speed(0.1)){
                    curtain = 150
                }})
            
            Image(uiImage: UIImage(named: "theend.png")!)
            .resizable()
            .frame(width: 300, height: 200)
            .padding(20)
            .opacity(end_opacity)
            .onAppear(perform: {withAnimation(Animation.easeIn.delay(1.5).speed(0.1))
                {
                    end_opacity = 1

                }})
        }
        .frame(width: 600, height: 400)
    }
}
PlaygroundPage.current.setLiveView(ContentView())
