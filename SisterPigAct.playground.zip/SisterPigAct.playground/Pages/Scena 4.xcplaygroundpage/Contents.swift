//: [Previous](@previous)

import Foundation
import SwiftUI
import PlaygroundSupport

struct BedView : View {
    @State var pallino1opacity = 0.0
    @State var pallino2opacity = 0.0
    @State var balloonopacity = 0.0
    @State var sparklescale = 1.0
    @State var scene1opacity = 1.0
    @State var scene2opacity = 0.0
    @State var phoneangle = 80.0
    @State var textopacity = 0.0
    let pallino1animation = Animation.easeIn
    let pallino2animation = Animation.easeIn.delay(1)
    let balloonanimation = Animation.easeIn.delay(2)
    let sparkleanimation = Animation.linear.repeatForever(autoreverses: true)
    let scene1animation = Animation.easeOut.delay(8)
    let scene2animation = Animation.easeIn.delay(7)
    let phoneanimation = Animation.linear.repeatForever(autoreverses: true)
    let textboxanimation = Animation.easeIn.speed(0.6)
    let textanimation = Animation.easeIn.speed(0.4).delay(1)
    var body: some View {
        ZStack{
            ZStack {
                Image(uiImage: UIImage(named: "4.png")!)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 600, height: 400)
                    .onAppear(perform: {
                        pallino1opacity = 1.0
                        pallino2opacity = 1.0
                        balloonopacity = 1.0
                        sparklescale = 0.2
                        scene1opacity = 0.0
                        scene2opacity = 1.0
                        textopacity = 1.0
                    })
                Image(uiImage: UIImage(named:"box_testo.png")!)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 600, height: 400)
                    .offset(y:153)
                    .opacity(textopacity)
                    .animation(textboxanimation)
                Text("Once back in the convent, Sister Pig can't stop thinking about that place.")
                    .bold()
                    .foregroundColor(.white)
                    .offset(y:170)
                    .frame(width: 570, height: 100)
                    .multilineTextAlignment(.center)
                    .opacity(textopacity)
                    .animation(textanimation)
                
                Image(uiImage: UIImage(named: "pallino1.png")!)
                    .resizable()
                    .frame(width: 20, height: 20)
                    .offset(x: -10, y: 40)
                    .opacity(pallino1opacity)
                    .animation(pallino1animation)
                Image(uiImage: UIImage(named: "pallino2.png")!)
                    .resizable()
                    .frame(width: 30, height: 30)
                    .offset(x: -45, y: 25)
                    .opacity(pallino2opacity)
                    .animation(pallino2animation)
                Image(uiImage: UIImage(named: "nuvoletta.png")!)
                    .resizable()
                    .frame(width: 300, height: 260)
                    .offset(x: -165, y: -100)
                    .opacity(balloonopacity)
                    .animation(balloonanimation)
                Image(uiImage: UIImage(named: "smart_off.png")!)
                    .resizable()
                    .frame (width: 167, height: 50)
                    .offset(x: -160, y: 80)
                Image(uiImage: UIImage(named: "sparkle.png")!)
                    .resizable()
                    .scaleEffect(sparklescale)
                    .frame (width: 26, height: 40)
                    .offset(x: 70, y: -35)
                    .animation(sparkleanimation)
                Image(uiImage: UIImage(named: "sparkle.png")!)
                    .resizable()
                    .scaleEffect(sparklescale)
                    .frame (width: 26, height: 40)
                    .offset(x: 185, y: -65)
                    .animation(sparkleanimation)
            }.opacity(scene1opacity)
                .animation(scene1animation)
            
            ZStack {
                Image(uiImage: UIImage(named: "4.2.png")!)
                    .resizable()
                    .frame(width: 600, height: 400)
                Image(uiImage: UIImage(named : "smart_on.png")!)
                    .resizable()
                    .frame (width: 167, height: 50)
                    .offset(x: -160, y: phoneangle)
                    .rotationEffect(.degrees(30))
                    .animation(phoneanimation)
                
            }.opacity(scene2opacity)
                .animation(scene2animation)
                .onAppear(perform: {
                    phoneangle = 40
                })
        }
    }
}

PlaygroundSupport.PlaygroundPage.current.setLiveView(BedView())

//: [Next](@next)
