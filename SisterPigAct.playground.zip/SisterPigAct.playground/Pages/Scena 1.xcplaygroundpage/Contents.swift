import SwiftUI
import PlaygroundSupport
import UIKit
import AVFoundation

let walkingAnimation = Animation.linear.repeatForever().repeatForever(autoreverses: true)

struct ContentView: View {
    @State private var button_opacity = 1.0
    @State private var logo_opacity = 1.0
    @State private var baloon_opacity = 0.0
    @State var verticalOffset = 65.0

    
    var body: some View {
        ZStack{
        Image(uiImage: UIImage(named: "1.1.png")!)
                .resizable()
                .frame(width: 600, height: 400)
                .padding(20)
        
        Image(uiImage: UIImage(named: "SeF.png")!)
                .resizable()
                .frame(width: 80, height: 50)
                .offset(x:-245,y:165)
                .opacity(logo_opacity)
                .padding(20)
            
        Image(uiImage: UIImage(named: "porca.png")!)
                    .resizable()
                    .frame(width: 300, height: 300)
                    .padding()
                    .offset(y:verticalOffset)
                    .onAppear(perform: {
                        withAnimation(walkingAnimation.speed(0.7)){
                            verticalOffset = 85
                        }})
                    
        
            VStack{
                Image(uiImage: UIImage(named: "titolo.png")!)
            .resizable()
            .frame(width: 200, height: 150)
            .offset(y:-50)
            .padding(20)
            .opacity(logo_opacity)
            
        Button {
            withAnimation {
                button_opacity = 0
                logo_opacity = 0
                baloon_opacity = 1
            }
            
        }label:{
            Image(uiImage: UIImage(named: "start.png")!)
                .resizable()
                .frame(width:100, height:65)
                .padding(20)

                
        }
        .offset(y:50)
        .opacity(button_opacity)
        .padding()
            }
            
        Image(uiImage: UIImage(named: "box_testo.png")!)
        .resizable()
        .frame(width: 600, height: 150)
        .offset(y:150)
        .padding(20)
        .opacity(baloon_opacity)

            Text("Sister Pig is blessing the sinners , as usual, together with the other sisters...")
                .foregroundColor(.white)
                .bold()
                .cornerRadius(10)
                .frame(width: 570, height: 100)
                .offset(y:170)
                .padding(20)
                .multilineTextAlignment(.center)
                .opacity(baloon_opacity)
            
            }.frame(width: 600, height: 400)
        }
        
        
    }
    
PlaygroundPage.current.setLiveView(ContentView())
