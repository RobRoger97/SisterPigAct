import SwiftUI
import PlaygroundSupport
import UIKit
import AVFoundation

let angleAnimation = Animation.linear.repeatForever().repeatForever(autoreverses: true)

struct ContentView: View {
    @State private var button_opacity = 1.0
    @State private var baloon_opacity = 0.0
    @State var verticalOffset = 80.0
    @State var scale: CGFloat = 1.5
    @State private var angle: Double = 0

    
    var body: some View {
        ZStack{
        Image(uiImage: UIImage(named: "3.1.png")!)
                .resizable()
                .frame(width: 600, height: 400)
                .padding(20)
            HStack{
        Image(uiImage: UIImage(named: "madre.png")!)
                             .resizable().rotationEffect( Angle.degrees(angle))
                             .frame(width: 329, height: 232)
                             .padding()
                             .offset(x:10,y:90)
                             
                             .onAppear(perform: {withAnimation(angleAnimation.speed(3))
                                 {
                                     angle = 2
                                     
                                 }})
                             
                
                Image(uiImage: UIImage(named: "pig.png")!)
                                         .resizable()
                                         .frame(width: 250, height: 250)
                                         .padding()
                                         .offset(x:-15,y:100)
            }
                HStack{
       Image(uiImage: UIImage(named: "cuore.png")!)
                    .resizable()
                    .frame(width: 30, height: 30)
                    .padding()
                    .offset()
                    .scaleEffect(scale)
                                .onAppear {
                                    let baseAnimation = Animation.easeInOut(duration: 1)
                                    let repeated = baseAnimation.repeatForever(autoreverses: true)

                                    withAnimation(repeated) {
                                        scale = 2
                                    }
                                }
        Image(uiImage: UIImage(named: "cuore.png")!)
                             .resizable()
                             .frame(width: 30, height: 30)
                             .padding()
                             .offset(x:-3)
                             .scaleEffect(scale)
                                         .onAppear {
                                             let baseAnimation = Animation.easeInOut(duration: 1)
                                             let repeated = baseAnimation.repeatForever(autoreverses: true)

                                             withAnimation(repeated) {
                                                 scale = 2
                                             }
                                         }}
                .offset(x:173,y:76)
                    
            
        
            Image(uiImage: UIImage(named: "box_testo.png")!)
            .resizable()
            .frame(width: 600, height: 190)
            .offset(y:150)
            .padding(20)
            .opacity(baloon_opacity)
            .onAppear(perform: {withAnimation(Animation.easeIn)
                {
                    baloon_opacity = 1
                    
                }})
            

                Text("While the other nuns are baffled... Sister Pig is fascinated !!")
                    .foregroundColor(Color(red:255,green:0,blue:255))
                    .bold()
                    .frame(width: 570, height: 100)
                    .offset(y:170)
                    .padding(20)
                    .opacity(baloon_opacity)
                    .animation(Animation.easeIn.delay(1))
                    
            
            }.frame(width: 600, height: 400)
        }
        
        
    }
  
PlaygroundPage.current.setLiveView(ContentView())
