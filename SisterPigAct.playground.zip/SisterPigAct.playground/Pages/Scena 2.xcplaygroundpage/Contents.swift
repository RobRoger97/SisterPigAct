//: [Previous](@previous)

import Foundation
import SwiftUI
import PlaygroundSupport

struct DiscoveryView : View {
    @State var nunsverticaloffset = 300.0
    @State var gallinaverticaloffset = 500.0
    @State var textopacity = 0.0
    let nunsanimation = Animation.easeOut.speed(0.3)
    let gallinanimation = Animation.easeOut.speed(0.2).delay(1.5)
    let textboxanimation = Animation.easeIn.speed(0.6).delay(2.2)
    let textanimation = Animation.easeIn.speed(0.4).delay(2.8)
    
    var body: some View {
        ZStack {
            Image(uiImage: UIImage(named:"lair")!)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 600, height: 400)
            
            Image(uiImage: UIImage(named: "nuns")!)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 600, height: 400)
                .offset(y: nunsverticaloffset)
                .onAppear(perform: {
                    withAnimation(nunsanimation){
                        nunsverticaloffset = 150
                    }
                })
            
            Image(uiImage: UIImage(named: "gallinaback")!)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 600, height: 400)
                .offset(y: gallinaverticaloffset)
                .scaleEffect(0.7)
                .onAppear(perform: {
                    withAnimation(gallinanimation){
                        gallinaverticaloffset = 170
                        textopacity = 1.0
                    }
                })
            Image(uiImage: UIImage(named:"box_testo.png")!)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 600, height: 400)
                .offset(y:153)
                .opacity(textopacity)
                .animation(textboxanimation)
            Text("Down the street they run into a strip club. The Mother Superior exclaims: 'Let's go into that hole of sinners!'")
                .bold()
                .frame(width: 570, height: 100)
                .foregroundColor(Color(red: 255, green: 0, blue: 255))
                .offset(y:170)
                .multilineTextAlignment(.center)
                .opacity(textopacity)
                .animation(textanimation)
        }
    }
}


PlaygroundSupport.PlaygroundPage.current.setLiveView(DiscoveryView())
//: [Next](@next)
