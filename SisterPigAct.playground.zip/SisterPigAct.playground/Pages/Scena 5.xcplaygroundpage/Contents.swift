import SwiftUI
import PlaygroundSupport
import UIKit
import AVFoundation

let upAnimation = Animation.linear

struct ContentView: View {
    @State private var f_opacity = 1.0
    @State private var s_opacity = 0.0
    @State private var t_opacity = 0.0
    @State private var baloon_opacity = 0.0
    @State var verticalOffset = 250.0
    
    var body: some View {
        ZStack{
        Image(uiImage: UIImage(named: "5.1.png")!)
                .resizable()
                .frame(width: 600, height: 400)
                .padding(20)
                .opacity(f_opacity)
                .onAppear(perform: {withAnimation(Animation.easeIn.speed(0.5))
                    {
                        f_opacity = 0
                        
                    }})
        Image(uiImage: UIImage(named: "5.2.png")!)
                    .resizable()
                    .frame(width: 600, height: 400)
                    .padding(20)
                    .opacity(s_opacity)
                    .onAppear(perform: {withAnimation(Animation.easeIn.speed(0.5))
                        {
                            s_opacity = 1
                            
                        }})
                    
            
       Image(uiImage: UIImage(named: "manocontelefono.png")!)
                   .resizable()
                   .frame(width: 450, height: 350)
                   .padding()
                   .offset(y:verticalOffset)
                   .onAppear(perform: {
                       withAnimation(upAnimation.speed(0.2)){
                            verticalOffset = 25
                            
                        }})
            Image(uiImage: UIImage(named: "light.png")!)
            .resizable()
            .frame(width: 450, height: 350)
            .padding()
            .offset(y:20)
            .opacity(t_opacity)
            .onAppear(perform: {withAnimation(Animation.easeIn.delay(0.3).speed(0.2))
                {
                    t_opacity = 1
                    
                }})
            
        
            Image(uiImage: UIImage(named: "box_testo.png")!)
            .resizable()
            .frame(width: 600, height: 190)
            .offset(y:150)
            .padding(20)
            .opacity(baloon_opacity)
            .onAppear(perform: {withAnimation(Animation.easeIn)
                {
                    baloon_opacity = 1
                    
                }})
            

                Text("Suddenly, a call arrives on her cell phone: 'Follow your heart! Goodness is in the heart of those who love!'")
                .foregroundColor(.white)
                    .bold()
                    .frame(width: 570, height: 100)
                    .offset(y:170)
                    .padding(20)
                    .opacity(baloon_opacity)
                    .multilineTextAlignment(.center)
                    .animation(Animation.easeIn.delay(0.5))
                    
            
            }.frame(width: 600, height: 400)
        }
        
        
    }
  
PlaygroundPage.current.setLiveView(ContentView())
