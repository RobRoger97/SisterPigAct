//: [Previous](@previous)

import Foundation
import SwiftUI
import PlaygroundSupport

struct DressingView : View {
    @State var verticaloffset = 460.0
    @State var hatopacity = 0.0
    let porkanimation = Animation.easeOut.speed(0.2)
    let hatanimation = Animation.easeIn.speed(0.5).delay(1.7)
    let textboxanimation = Animation.easeIn.speed(0.6).delay(2.7)
    let textanimation = Animation.easeIn.speed(0.4).delay(3.3)
    var body: some View {
        ZStack {
            Image(uiImage: UIImage(named: "6.1")!)
                .resizable()
                .frame(width: 600, height: 400)
                .onAppear(perform: {
                    verticaloffset = 60.0
                    hatopacity = 1.0
                })
            Image(uiImage: UIImage(named: "porkaback")!)
                .resizable()
                .frame(width: 340, height: 290)
                .offset(x: -35, y: verticaloffset)
                .animation(porkanimation)
            Image(uiImage: UIImage(named: "cappello.png")!)
                .resizable()
                .frame(width: 118, height: 70)
                .offset(x: 250, y: 130)
                .opacity(hatopacity)
                .animation(hatanimation)
            Image(uiImage: UIImage(named:"box_testo.png")!)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 600, height: 400)
                .offset(y:153)
                .opacity(hatopacity)
                .animation(textboxanimation)
            Text("Sister Pig felt relieved, stripped off her nun robes and she wore the clothes she liked best...")
                .bold()
                .frame(width: 570, height: 100)
                .foregroundColor(Color(red: 255, green: 0, blue: 255))
                .offset(y:170)
                .multilineTextAlignment(.center)
                .opacity(hatopacity)
                .animation(textanimation)
            
        }
    }
}

PlaygroundPage.current.setLiveView(DressingView())
//: [Next](@next)
